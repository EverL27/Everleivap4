:root {
  position : relative;
  min-height: 100%;
}
.lightbox-wrap {
  background-color: rgba(50, 50, 50, 0.9);
  color : #fff;
  display : flex;
  position : absolute;
  left : 0;
  right : 0;
  top : 0;
  bottom : 0;
  z-index : 99999999;
}

.lightbox {
  margin : auto;
  position : relative;
  max-width : 80vw;
  margin-top : 7vh;
}
.lightbox__content {
  display : block;
  border : 0;
  max-width : 80vw;
  max-height : 75vh;
  border : 0;
  position : relative;
  margin : auto;
}

.lightbox__content--iframe {
  width : 80vw;
}

.lightbox__content--iframe::before {
  content : '';
  display : block;
  padding-top : 56.25%;
  position : relative;
  z-index : -2;
}

.lightbox__content--iframe::after {
  content : 'Loading..';
  position : absolute;
  top : 50%;
  width : 100%;
  text-align : center;
  z-index : -1;
}
.lightbox__iframe {
  border : 0;
  bottom : 0;
  height : 100%;
  left : 0;
  position : absolute;
  right : 0;
  top : 0;
  width : 100%;
}
.lightbox__title,
.lightbox__caption {
  max-width : 600px;
  margin : auto;
}

.lightbox__title {
  font-size : 20px;
  font-weight : 900;
  margin-top : 30px;
}
.lightbox__prev,
.lightbox__next,
.lightbox__close {
  position : absolute;
  cursor : pointer; 
}
.lightbox__prev,
.lightbox__next {
  top : 50 : 50px;
    width : 30px;
  }
  .lightbox__prev {
    right : calc(100% + 20px);
  }
  .lightbox__next {
    left : calc(100% + 20px);
  }
}